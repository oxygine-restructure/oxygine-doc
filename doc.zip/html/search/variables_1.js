var searchData=
[
  ['companyname',['companyName',['../structoxygine_1_1core_1_1init__desc.html#a81e5f1b0dfd1799d612ccaaa386822f7',1,'oxygine::core::init_desc']]],
  ['created',['created',['../classoxygine_1_1_native_texture.html#a051ef2a52161200c411617ab5804cb4d',1,'oxygine::NativeTexture']]]
];
