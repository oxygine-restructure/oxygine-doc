var searchData=
[
  ['allowcomments_5f',['allowComments_',['../class_json_1_1_features.html#a33afd389719624b6bdb23950b3c346c9',1,'Json::Features']]],
  ['appname',['appName',['../structoxygine_1_1core_1_1init__desc.html#a4750b5fc718c31b7235ae5bb445b4415',1,'oxygine::core::init_desc']]]
];
