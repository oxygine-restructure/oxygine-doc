var searchData=
[
  ['force_5fgles',['force_gles',['../structoxygine_1_1core_1_1init__desc.html#adb137fca61e3618d0e0ec5e246a1c02d',1,'oxygine::core::init_desc']]],
  ['fullscreen',['fullscreen',['../structoxygine_1_1core_1_1init__desc.html#a44a13945efd8bc3b953732701f31d5f9',1,'oxygine::core::init_desc']]]
];
