var searchData=
[
  ['jnigetlanguage',['jniGetLanguage',['../namespaceoxygine.html#afa7896e273cbaed679934d1f213e8c43',1,'oxygine']]],
  ['jnigettimeutcms',['jniGetTimeUTCMS',['../namespaceoxygine.html#ad051ac2dfe38d9a39176f0307e4c0c5a',1,'oxygine']]],
  ['json',['Json',['../namespace_json.html',1,'']]]
];
