var searchData=
[
  ['haseventlisteners',['hasEventListeners',['../classoxygine_1_1_event_dispatcher.html#a0b605ef8cb965cc96b642f9c2649fc40',1,'oxygine::EventDispatcher::hasEventListeners(void *CallbackThis)'],['../classoxygine_1_1_event_dispatcher.html#ac20201c01391b6d5ff2c92fed3b5d4b2',1,'oxygine::EventDispatcher::hasEventListeners(eventType, const EventCallback &amp;)']]]
];
